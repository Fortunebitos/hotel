const MenuItems = [
    {
        link: "Bgimage",
        path: "/imgbg.png"
    },
       {
        link: "Bgimage",
        path: "/imgbg.png"
    },
       {
        link: "Bgimage",
        path: "/imgbg.png"
    },
       {
        link: "Bgimage",
        path: "/imgbg.png"
    },
     

]

export default MenuItems