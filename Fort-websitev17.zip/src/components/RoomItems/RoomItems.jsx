import React from "react";

const RoomItems = () => {
  return (
    <div>
      <ul>
        <li className="t1">Wi-Fi Internet access</li>
        <li className="t1">LCD TV with cable channels</li>
        <li className="t1">Mini-bar</li>
        <li className="t1">Refrigerator</li>
        <li className="t1">Coffee and tea maker</li>
        <li className="t1">Private toilet with bathtub and shower</li>
        <li className="t1">Toiletries, hair dryer, bathrobe</li>
        <li className="t1">Balcony</li>
        <li className="t1">Desk with lamp</li>
        <li className="t1">Blackout curtains</li>
        <li className="t1">Ironing facilities</li>
        <li className="t1">Phone</li>
        <li className="t1">Safe</li>
        <li className="t1">Alarm clock</li>
        <li className="t1">Air-conditioning</li>
        <li className="t1">Non-smoking</li>
      </ul>
    </div>
  );
};

export default RoomItems;
