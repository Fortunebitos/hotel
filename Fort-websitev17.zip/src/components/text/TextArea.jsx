import React from "react";
import TButton from '../../components/button/TButton'

const TextArea = () => {
    return (
        <>
            <textarea rows="5" cols="50"></textarea>
            <TButton label="SEND NUDES" />
        </>
    );
};

export default TextArea;