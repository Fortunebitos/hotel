const General = [
  "https://i.ibb.co/VNv4sLr/photo-1582719478250-c89cae4dc85b-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/QvRHLwn/photo-1618773928121-c32242e63f39-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/sKf0hxj/photo-1631049552057-403cdb8f0658-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/Jp6c3zr/photo-1631049421450-348ccd7f8949-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/XDXqH7X/photo-1621293954908-907159247fc8-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/VpYcxz0/photo-1598928636135-d146006ff4be-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/pXgtT3v/photo-1540518614846-7eded433c457-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/KFKZ49f/photo-1611892441796-ae6af0ec2cc8-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/g6pw9RM/photo-1631048834981-27b558f7a3e7-ixlib-rb-1-2.jpg",
];

const Rooms = [
  "https://i.ibb.co/VNv4sLr/photo-1582719478250-c89cae4dc85b-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/QvRHLwn/photo-1618773928121-c32242e63f39-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/sKf0hxj/photo-1631049552057-403cdb8f0658-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/Jp6c3zr/photo-1631049421450-348ccd7f8949-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/XDXqH7X/photo-1621293954908-907159247fc8-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/VpYcxz0/photo-1598928636135-d146006ff4be-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/pXgtT3v/photo-1540518614846-7eded433c457-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/KFKZ49f/photo-1611892441796-ae6af0ec2cc8-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/g6pw9RM/photo-1631048834981-27b558f7a3e7-ixlib-rb-1-2.jpg",
];

const Pool = [
  "https://i.ibb.co/VNv4sLr/photo-1582719478250-c89cae4dc85b-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/QvRHLwn/photo-1618773928121-c32242e63f39-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/sKf0hxj/photo-1631049552057-403cdb8f0658-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/Jp6c3zr/photo-1631049421450-348ccd7f8949-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/XDXqH7X/photo-1621293954908-907159247fc8-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/VpYcxz0/photo-1598928636135-d146006ff4be-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/pXgtT3v/photo-1540518614846-7eded433c457-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/KFKZ49f/photo-1611892441796-ae6af0ec2cc8-ixlib-rb-1-2.jpg",
  "https://i.ibb.co/g6pw9RM/photo-1631048834981-27b558f7a3e7-ixlib-rb-1-2.jpg",
];

const RItems = [
  {
    name: "Beautiful Place and clean Pool",
    rate: "5",
  },

  {
    name: "Beautiful Place and clean Pool",
    rate: "5",
  },

  {
    name: "Beautiful Place and clean Pool",
    des: "5",
  },
];
export { General, Rooms, Pool, RItems };
