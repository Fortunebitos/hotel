const RDatu = [
  {
    icon: "https://i.ibb.co/VNv4sLr/photo-1582719478250-c89cae4dc85b-ixlib-rb-1-2.jpg",
    name: "Fortune Bitos Jr.",
    star: "1",
    time: "1 week ago",
    content: "Nice Place and beautiful staff and also beautiful pool",
  },
  {
    icon: "https://i.ibb.co/QvRHLwn/photo-1618773928121-c32242e63f39-ixlib-rb-1-2.jpg",
    name: "Rey Mimis",
    star: "4",
    time: "3 days ago",
    content: "Nice Place",
  },
  {
    icon: "https://i.ibb.co/W0Ybc6h/photo-1591088398332-8a7791972843-ixlib-rb-1-2.jpg",
    name: "Chriz Bobis",
    star: "5",
    time: "4 weeks ago",
    content: "Beautiful Staff.",
  },
  {
    icon: "https://i.ibb.co/sKf0hxj/photo-1631049552057-403cdb8f0658-ixlib-rb-1-2.jpg",
    name: "Richard Cleofe",
    star: "4",
    time: "2 weeks ago",
    content: " The Staff are beautifull.",
  },
  {
    icon: "https://i.ibb.co/Jp6c3zr/photo-1631049421450-348ccd7f8949-ixlib-rb-1-2.jpg",
    name: "Geronel Moraga",
    star: "3",
    time: "1 week ago",
    content: "The bathroom are clean",
  },
  {
    icon: "https://i.ibb.co/XDXqH7X/photo-1621293954908-907159247fc8-ixlib-rb-1-2.jpg",
    name: "Jericho Vilog",
    star: "4",
    time: "2 years ago",
    content: "The bathroom are clean.",
  },
  {
    icon: "https://i.ibb.co/VpYcxz0/photo-1598928636135-d146006ff4be-ixlib-rb-1-2.jpg",
    name: "Gelay Vlancia",
    star: "5",
    time: "4 months ago",
    content: "Neat and clean room with courteous staff.",
  },
  {
    icon: "https://i.ibb.co/pXgtT3v/photo-1540518614846-7eded433c457-ixlib-rb-1-2.jpg",
    name: "Anthony Oling",
    star: "4",
    time: "2 months ago",
    content: "So good and also the rooms.",
  },
  {
    icon: "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",

    name: "Ann Curtis",
    star: "3",
    time: "1 month ago",
    content: "Beautiful place.",
  },
  {
    icon: "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",

    name: "Mark Tindoc",
    star: "4",
    time: "2 months ago",
    content: "The staff is  very accumadating",
  },
  {
    icon: "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",

    name: "Chrisalyn Fernandez",
    star: "5",
    time: "1 week ago",
    content: "The swimming pool is very clean.",
  },
  {
    icon: "https://i.ibb.co/W0Ybc6h/photo-1591088398332-8a7791972843-ixlib-rb-1-2.jpg",
    name: "Bruno Mars",
    star: "1",
    time: "1 months ago",
    content: "The rooms and the bathrooms very clean.",
  },
  {
    icon: "https://i.ibb.co/W0Ybc6h/photo-1591088398332-8a7791972843-ixlib-rb-1-2.jpg",
    name: "Bruno Mars",
    star: "1",
    time: "1 months ago",
    content: "The rooms and the bathrooms very clean.",
  },
  {
    icon: "https://i.ibb.co/3RbZX3h/photo-1594563703937-fdc640497dcd-ixlib-rb-1-2.jpg",
    name: "Chrisalyn Fernandez",
    star: "5",
    time: "1 week ago",
    content: "The swimming pool is very clean.",
  },
];

const RStar1 = [
  {
    star: "5",
  },
];

export { RDatu, RStar1 };
