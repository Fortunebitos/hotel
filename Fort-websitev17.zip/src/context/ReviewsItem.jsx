const FBItem = [
  {
    title: "All Reviews",
    count: 1.4,
  },
  {
    title: "Facebook",
    count: 5.5,
  },
  {
    title: "Twitter",
    count: 5.9,
  },
  {
    title: "Youtube",
    count: 1.5,
  },
];

export default FBItem;
