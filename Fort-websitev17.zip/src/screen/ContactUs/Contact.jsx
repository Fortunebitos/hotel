import React from "react";
import Cnitem from "../../components/CnItems/CNitems";

const Contact = () => {
  return (
    <>
      <div>
        <Cnitem />
      </div>
    </>
  );
};

export default Contact;
